package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("controller")
@ComponentScan("dao")
@ComponentScan("service")
@ComponentScan("model")
@EntityScan(basePackages = {"model"})
public class AssessmentmodularApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssessmentmodularApplication.class, args);
	}

}
