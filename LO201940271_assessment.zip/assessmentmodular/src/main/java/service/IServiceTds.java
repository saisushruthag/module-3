package service;

import model.TDSMaster;

public interface IServiceTds {
	
	public TDSMaster getByID(int id);

}
