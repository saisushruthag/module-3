package dao;

import model.TDSMaster;

public interface ITdsDao {

	public TDSMaster getById(int id);

}
